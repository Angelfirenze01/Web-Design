I rewrote the entire <a href="https://teamtreehouse.com/home" target="_blank">Team Treehouse</a> How To Make A Website course after reviewing the first parts and realizing I don't like my <a href="https://github.com/Angelfirenze01/Web-Design/tree/master/How-To-Make-A-Website" target="_blank">original attempt</a>, which was written with the boilerplate design specs.

I realized it was a lot more interesting, not to mention fun, if I used my own photographs saved in my Instagram account, and my Photobucket.

I found out today that I've enjoyed the course a lot more while thinking up my own styles to impart upon the original stylesheet.

<img src="http://img.photobucket.com/albums/v204/Angelfirenze/Team%20Treehouse/Treehouse-Logo-Outlines_zpse2fmsdyp.png"> 

<center>&copy 2017 Treehouse Island, Inc.</center>
